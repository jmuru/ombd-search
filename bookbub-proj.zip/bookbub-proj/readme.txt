In order to run the program just open up python in terminal and run ratings.py (might tak a while)

approximate time until completeion: 2 hours 30 min